


public class Starting {
	public static void main(String[] args) {		
		FrmNhanVien frm = new FrmNhanVien();
		frm.setVisible(true);
	}
}
